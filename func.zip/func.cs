#r "Microsoft.WindowsAzure.Storage"

using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;

public static void Run(Stream myBlob, string name, ILogger log)
{
    log.LogInformation($"C# Blob trigger function Processed blob\n Name:{name} \n Size: {myBlob.Length} Bytes");

    string dateFormat = "yyyy.MM.dd.hh.mm.ss.fffffff"; 

    string blobNameNew = name + "-" + DateTime.UtcNow.ToString(dateFormat);

    log.LogInformation($"Copy blob\n to Name:{blobNameNew}");

    var connectionString = GetEnvironmentVariable("Destination_STORAGE");

    //var connectionString = "DefaultEndpointsProtocol=https;AccountName=devsatfstatebackup50007;AccountKey=yi+LMQx22k6aOL+VpEccq6In4jPgHspb2X828oJCupFB2W5T+34H5d6NLZaHb0I+xBH2NbymO0xATEfLxqnfCQ==;EndpointSuffix=core.windows.net";

    CloudStorageAccount storageAccount = CloudStorageAccount.Parse(connectionString);

    CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();

    log.LogInformation($"Connection string is\n Name:{connectionString}");

    CloudBlobContainer container = blobClient.GetContainerReference("terraform-state-dev");

    CloudBlockBlob blockBlob = container.GetBlockBlobReference(blobNameNew);

    //await 

    blockBlob.UploadFromStreamAsync(myBlob);

    log.LogInformation($"Finished copy:{name} to:{blobNameNew}");
}

public static string GetEnvironmentVariable(string name)
{
    return System.Environment.GetEnvironmentVariable(name, EnvironmentVariableTarget.Process);
}
